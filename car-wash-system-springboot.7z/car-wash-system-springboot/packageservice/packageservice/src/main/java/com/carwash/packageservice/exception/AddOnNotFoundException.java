package com.carwash.packageservice.exception;

public class AddOnNotFoundException extends RuntimeException {
    public AddOnNotFoundException(String messege) {
        super(messege);
    }
}
