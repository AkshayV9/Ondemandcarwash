package com.carwash.packageservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PackageserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
