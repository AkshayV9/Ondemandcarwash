package com.carwash.orderservice.model;

public enum Gender {
    MALE,FEMALE
}
