package com.carwash.washerservice.exception;

public class UserNameException extends RuntimeException{

    public UserNameException(String message) {
        super(message);
    }
}
