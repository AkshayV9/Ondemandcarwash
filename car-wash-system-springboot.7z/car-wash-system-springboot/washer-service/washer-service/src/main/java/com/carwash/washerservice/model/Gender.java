package com.carwash.washerservice.model;

public enum Gender {
    MALE,FEMALE
}
