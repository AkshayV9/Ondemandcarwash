package com.carwash.washerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WasherServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
