package com.carwash.userservice.exception;

public class PhoneNoException extends RuntimeException {
    public PhoneNoException(String message) {
        super(message);
    }
}
