package com.carwash.userservice.exception;

public class UserNameException extends RuntimeException{

    public UserNameException(String message) {
        super(message);
    }
}
