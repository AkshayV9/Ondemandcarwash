package com.carwash.userservice.model;

public enum Role {
    ADMIN,USER,WASHER
}
