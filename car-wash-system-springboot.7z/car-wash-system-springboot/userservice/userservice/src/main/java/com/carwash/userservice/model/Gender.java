package com.carwash.userservice.model;

public enum Gender {
    MALE,FEMALE
}
